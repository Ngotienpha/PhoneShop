<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductController2;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CommentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('list', [ProductController::class, 'index']);
Route::get('add', [ProductController::class, 'add']);
Route::post('save', [ProductController::class, 'save']);
Route::get('edit/{id}', [ProductController::class, 'edit']);
Route::post('update', [ProductController::class, 'update']);
Route::get('delete/{id}', [ProductController::class, 'delete']);

Route::get('list2', [CommentController::class, 'index']);
Route::get('add2', [CommentController::class, 'add2']);
Route::post('save', [CommentController::class, 'save']);
Route::get('edit2/{id}', [CommentController::class, 'edit2']);
Route::post('update', [CommentController::class, 'update']);
Route::get('delete/{id}', [CommentController::class, 'delete']);

Route::get('/', [ProductController2::class, 'index']);
Route::get('/products', [ProductController2::class, 'getProducts']);

Route::get('/register', [CustomerController::class, 'register']);
Route::get('/login', [CustomerController::class, 'login']);
Route::post('/register-process', [CustomerController::class, 'registerProcess'])->name('register-process');
Route::post('/login-process', [CustomerController::class, 'loginProcess'])->name('login-process');
Route::get('/logout', [CustomerController::class, 'logout']);
