<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Khách hàng đánh giá</title>
  </head>
  <body>
    <div class="container" style="margin-top: 50px">
        <div class="row">
            <div class="col-md-12">
                <h2>Danh sách các đánh giá về sản phẩm</h2>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <div style="margin-right: 10%; float: right;">
                    <a href="<?php echo e(url('add2')); ?>" class="btn btn-outline-success">Thêm đánh giá từ khách hàng VIP</a>
                </div>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Details</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->commentID); ?></td>
                                <td><?php echo e($row->commentName); ?></td>
                                <td><?php echo e($row->commentDetails); ?></td>
                                <td>
                                    <a href="<?php echo e(url('edit2/'. $row->commentID)); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(url('delete/'. $row->commentID)); ?>" class="btn btn-danger"
                                        onclick="return confirm('Bạn chắc chắn xóa đánh giá của khách?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\PhoneSale\resources\views/list2.blade.php ENDPATH**/ ?>