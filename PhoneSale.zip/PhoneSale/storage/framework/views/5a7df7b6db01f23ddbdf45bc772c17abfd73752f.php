<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Add product</title>
  </head>
  <body>
    <div class="container" style="margin-top: 50px">
        <div class="row">
            <div class="col-md-12">
                <h2>Add new product</h2>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(url('save')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="md-3">
                        <label for="id" class="form-label">ID</label>
                        <input type="text" name="id" class="form-control"
                                placeholder="Enter product id">
                    </div>
                    <div class="md-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" class="form-control"
                                placeholder="Enter product name">
                    </div>
                    <div class="md-3">
                        <label for="price" class="form-label">Price</label>
                        <input type="text" name="price" class="form-control"
                                placeholder="Enter product price">
                    </div>
                    <div class="md-3">
                        <label for="image1" class="form-label">Image</label>
                        <input type="file" name="image1" class="form-control"
                                placeholder="Enter product image">
                    </div>
                    <div class="md-3">
                        <label for="producer" class="form-label">Producer</label>
                        <select name="producer" class="form-control">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($row->producerID); ?>"><?php echo e($row->producerName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div> <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <a href="<?php echo e(url('list')); ?>" class="btn btn-success">Back</a>
                </form>
            </div>
        </div>
    </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\PhoneSale\resources\views/add.blade.php ENDPATH**/ ?>