<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Shop bán Điện Thoại</title>
  </head>
  <body>
    <div class="container" style="margin-top: 50px">
        <div class="row">
            <div class="col-md-12">
                <h2>Danh sách sản phẩm</h2>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <div style="margin-right: 10%; float: right;">
                    <a href="<?php echo e(url('add')); ?>" class="btn btn-outline-success">Thêm sản phẩm</a>
                </div>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->productID); ?></td>
                                <td><?php echo e($row->productName); ?></td>
                                <td><?php echo e($row->productPrice); ?></td>
                                <td><img src="images/products/<?php echo e($row->productImage1); ?>" 
                                         alt="" srcset="" height="90px" width="90px"></td>
                                <td>
                                    <a href="<?php echo e(url('edit/'. $row->productID)); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(url('delete/'. $row->productID)); ?>" class="btn btn-danger"
                                        onclick="return confirm('Bạn chắc chắn xóa sản phẩm này?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\PhoneSale\resources\views/list.blade.php ENDPATH**/ ?>