<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Edit comment</title>
  </head>
  <body>
    <div class="container" style="margin-top: 50px">
        <div class="row">
            <div class="col-md-12">
                <h2>Chỉnh sửa Đánh giá</h2>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(url('update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="md-3">
                        <label for="id" class="form-label">ID</label>
                        <input type="text" name="id" class="form-control"
                                value="<?php echo e($data->commentID); ?>" readonly>
                    </div>
                    <div class="md-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" class="form-control"
                               value="<?php echo e($data->commentName); ?>">
                    </div>
                    <div class="md-3">
                        <label for="details" class="form-label">Details</label>
                        <input type="text" name="details" class="form-control"
                               value="<?php echo e($data->commentDetails); ?>">
                    </div>
                    <div class="md-3">
                        <label for="customer" class="form-label">Customer</label>
                        <select name="customer" class="form-control">
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->customerID); ?>" <?php echo e($row->customerID == $data->customerID ? 'selected' : ''); ?>>
                                    <?php echo e($row->customerName); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div> <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <a href="<?php echo e(url('list2')); ?>" class="btn btn-success">Back</a>
                </form>
            </div>
        </div>
    </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\PhoneSale\resources\views/edit2.blade.php ENDPATH**/ ?>