create database KimAnhLy;

use KimAnhLy;

create table producers
(
	producerID int auto_increment primary key,
    producername varchar(30) not null unique
);

create table products
(
	productID varchar(5) not null primary key,
    productName varchar(50) not null,
    productPrice int not null,
    productImage1 varchar(30) not null,
    productImage2 varchar(30) null,
	productImage3 varchar(30) null,
    producerID int not null,
    constraint foreign key (producerID) references producers(producerID)
);

create table customers
(
	customerID varchar(30) not null primary key,
    customerName varchar(50) not null,
    customerEmail varchar(100) null,
    customerPhone varchar(12) null
);

create table bills
(
	billID varchar(30) not null primary key,
    productID varchar(5) not null,
	constraint foreign key (productID) references products(productID),
    number int not null
);

create table billDetails
(
	billID varchar(30) not null primary key,
    constraint foreign key (billID) references bills(billID),
    customerID varchar(30) not null,
    constraint foreign key (customerID) references customers(customerID)
);

create table comments
(
	commentID varchar(30) not null primary key,
    commentName varchar(50) not null,
    commentDetails varchar(100) not null,
    customerID varchar(30) not null,
    constraint foreign key (customerID) references customers(customerID)
);

-- insert data
insert into producers(producerName) values
('Samsung'), ('Apple'), ('LG'), ('Nokia'), ('Xiaomi'), ('Oppo');

select * from producers;

insert into products(productID, productName, productPrice, productImage1, producerID) values
('PO01', 'Samsung Galaxy S22', '560', 'product01.jpg', '1'),
('PO02', 'Samsung Galaxy S22 Ultra', '950', 'product02.jpg', '2'),
('PO03', 'Iphone13 Pro max', '1330', 'product03.jpg', '2'),
('PO04', 'Iphone 13 Pro', '1000', 'product04.jpg', '2'),
('PO05', 'Iphone 13 Max', '1420', 'product05.jpg', '1');

select * from products;

create table admins
(
	adminID varchar(30) not null primary key,
    adminName varchar(50) not null,
    adminPhone varchar(12) null,
    adminEmail varchar(100) null
);