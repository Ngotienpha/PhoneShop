<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\Customer;

class CommentController extends Controller
{
    public function index()
    {
        $data = Comment::get();
        return view('list2', compact('data'));
    }

    public function add2()
    {
        $data = Customer::get();
        return view('add2', compact('data'));
    }

    public function save(Request $request)
    {
        $id = $request->id;
        $name = $request->name;
        $details = $request->details;
        $customer = $request->customer;

        $comment = new Comment();
        $comment->commentID = $request->id;
        $comment->commentName = $request->name;
        $comment->commentDetails = $request->details;
        $comment->customerID = $request->customer;
        $comment->save();

        return redirect()->back()->with('Success', 'Bạn đã thêm đánh giá thành công');
    }
    
    public function edit2($id)
    {
        $customers = Customer::get();
        $data = Comment::where('commentID', '=', $id)->first();
        return view('edit2', compact('data', 'customers'));
    }

    public function update(Request $request)
    {
        $id = $request->id;
        Comment::where('commentID', '=', $id)->update([
            'commentName'=>$request->name,
            'commentDetails'=>$request->details,
            'customerID'=>$request->customer
        ]);
        return redirect()->back()->with('success', 'Đánh giá đã cập nhật thành công');
    }

    public function delete($id)
    {
        Comment::where('commentID', '=', $id)->delete();
        return redirect()->back()->with('success', 'Bạn đã xóa đánh giá này');
    }
}

