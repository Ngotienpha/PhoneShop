<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController2 extends Controller
{
    public function index()
    {
        $data = Product::get();
        return view('customer.home', compact('data'));
    }

    public function getProducts()
    {
        $data = Product::get();
        return view('customer.products', compact('data'));
    }
}
