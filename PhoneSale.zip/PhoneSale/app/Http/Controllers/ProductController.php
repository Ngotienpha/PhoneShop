<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Producer;

class ProductController extends Controller
{
    public function index()
    {
        $data = Product::get();
        return view('list', compact('data'));
    }

    public function index2()
    {
        $data = Product::select('products.*', 'producers.producerName')
            -> join('producer','producers.producerID', '=', 'products.producerID')
            -> get(); //or first()
        return view('list2', compact('data'));
    }

    public function add()
    {
        $data = Producer::get();
        return view('add', compact('data'));
    }

    public function save(Request $request)
    {
        $id = $request->id;
        $name = $request->name;
        $price = $request->price;
        $image1 = $request->image1;
        $producer = $request->producer;

        $product = new Product();
        $product->productID = $request->id;
        $product->productName = $request->name;
        $product->productPrice = $request->price;
        $product->productImage1 = $request->image1;
        $product->producerID = $request->producer;
        $product->save();

        return redirect()->back()->with('Success', 'Bạn đã thêm sản phẩm thành công');
    }
    
    public function edit($id)
    {
        $producers = Producer::get();
        $data = Product::where('productID', '=', $id)->first();
        return view('edit', compact('data', 'producers'));
    }

    public function update(Request $request)
    {
        $id = $request->id;
        Product::where('productID', '=', $id)->update([
            'productName'=>$request->name,
            'productPrice'=>$request->price,
            'productImage1'=>$request->image1,
            'producerID'=>$request->producer
        ]);
        return redirect()->back()->with('success', 'Sản phẩm đã cập nhật thành công');
    }

    public function delete($id)
    {
        Product::where('productID', '=', $id)->delete();
        return redirect()->back()->with('success', 'Bạn đã xóa sản phẩm này');
    }
}
